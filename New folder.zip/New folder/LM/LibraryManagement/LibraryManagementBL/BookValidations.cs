﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LibraryManagement;
using LibraryManagementExcetion;
using LibraryManagement.DAL;

namespace LibraryManagementBL
{
    public class BookValidations
    {
        public static bool ValidateBook(Book B)
        {
            bool BValidated = true;
            StringBuilder message = new StringBuilder();

            try
            {
                //Checking - employee id should be 6 digit
                if (B.BookId < 5)
                {
                    BValidated = false;
                    message.Append("Book ID should be exactly 5 digits long\n");
                }

                //Checking - employee name
                if (B.BookName == String.Empty)
                {
                    BValidated = false;
                    message.Append("Book Name should be provided\n");

                }
                if (B.Language == String.Empty)
                {
                    B.Language = "english";


                }
                if (B.Iot == String.Empty)
                {
                    B.Iot = "Technical";


                }
            }
            catch (LibraryException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return BValidated;

        }

        public static bool AddBookDetails(Book B)
        {
            bool BAdded = false;

            try
            {
                if (ValidateBook(B))
                {
                    BAdded = LibraryOperation.AddBookDetails(B);
                }
                else
                {
                    throw new LibraryException("Please provide valid data for employee");
                }
            }
            catch (LibraryException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return BAdded;
        }

        public static bool SerializeBook()
        {
            bool BSerialized = false;

            try
            {
                BSerialized = LibraryOperation.SerializeBook();
            }
            catch (LibraryException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return BSerialized;
        }
        public static List<Book> DeserializeBook()
        {
            List<Book> BDesList = null;

            try
            {
                BDesList = LibraryOperation.DeserializeBook();
            }
            catch (LibraryException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return BDesList;

        }
        public static List<Book> RetrieveEmployees()
        {
            List<Book> bookList = LibraryOperation.RetrieveEmployees();

            return bookList;
        }
    }

}

    
