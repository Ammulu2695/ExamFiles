﻿ using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NewMovieEntity;//using reference of newMovieEntity
using NewMovieException;//using reference of newMovieEntity
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;


namespace NewMovieDAL
{
    public class NewMovieOperations
    {
        static List<Movie> MTList = new List<Movie>();
        //private static readonly object MovieList;

        //To insert the movie tite in movie list
        public static bool AddMovieDetails(Movie T)
        {
            bool TAdded = false;

            try
            {
                //Adding movietitle object into movie list
                MTList.Add(T);
                TAdded = true;
                
            }
            catch (MovieException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return TAdded;
        }
        public static List<Movie> RetrieveEmployeesDal()
        {
            return MTList;
        }

        // //to serialize the movielist
        public static bool SerializeMovie()
        {
            bool MovieSerialized = false;

            try
            {
                FileStream fs = new FileStream("Movie.txt", FileMode.Create, FileAccess.Write);
                BinaryFormatter bin = new BinaryFormatter();
                bin.Serialize(fs, MTList);
                fs.Close();
                MovieSerialized = true;
            }
            catch (MovieException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return MovieSerialized;
        }
        //To deserialize employee List
        public static List<Movie> DeserializeMovie()
        {
            List<Movie> MovieDesList = null;

            try
            {
                FileStream fs = new FileStream("Movie.txt", FileMode.Open, FileAccess.Read);
                BinaryFormatter bin = new BinaryFormatter();
                MovieDesList = (List<Movie>)bin.Deserialize(fs);
                fs.Close();
            }
            catch (MovieException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return MovieDesList;
        }

    }
}

        