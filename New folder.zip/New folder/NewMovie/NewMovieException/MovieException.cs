﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NewMovieException
{
    public class MovieException : ApplicationException
    {

        //Default Constructor
        public MovieException() : base()
            { }

        //Parameterized Constructor to initialize Message property
        public MovieException(string message) : base(message)
            { }
        }
    }



