﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NewMovieEntity;//using reference of newMovieEntity
using NewMovieException;//using reference of newMovieEntity
using System.IO;
using NewMovieDAL;//using refernce of NewmovieDAL
using System.Text.RegularExpressions;

namespace NewmovieBL
{
    public class MovieValidation
    {


        public static bool ValidateMovie(Movie T)
        {
            bool TValidated = true;
            StringBuilder message = new StringBuilder();

            try
            {
                //Checking - Movie name
                if (T.MovieTitle == String.Empty)
                {
                    TValidated = false;
                    message.Append("Movie title should be provided\n");
                }
                else if (!Regex.IsMatch(T.MovieTitle, "[A-Z][a-z]{2,}"))
                {
                    TValidated = false;
                    message.Append("movie name starts with capital letter followed by small alphabets");
                } //checking publisher
                if (T.Publisher == String.Empty)
                {
                    TValidated = false;
                    message.Append("Publisher should be provided\n");
                }
               else if (!Regex.IsMatch(T.Publisher, "[A-Z][a-z]{2,}"))
                {
                    TValidated = false;
                    message.Append("movie Publisher starts with capital letter followed by small alphabets");
                }
                //int age = DateTime.Today.Year - emp.DOB.Year;
                //if (age < 18 || age > 60)
                //{
                //    empValidated = false;
                //    message.Append("As per the Date of Birth Employee age should be within 18 to 60\n");
                //}

                //if (T.MovieReleased < DateTime.Now)
                //{
                //    TValidated = false;
                //    message.Append("movie is released date must be before present day ");
                //}
                if (T.MovieReleased > DateTime.Now)
                {
                    TValidated = false;
                    message.Append("movie is released date must be before present day ");
                }

                if (T.Acting <0 || T.Acting >5 )
                {
                    TValidated = false;
                    message.Append(" acting rating b/w 0-5:");
                }
                if (T.Cinematography < 0 || T.Cinematography > 5)
                {
                    TValidated = false;
                    message.Append("Cinematography rating b/w 0-5:");
                }
                if (T.Music <0 || T.Music>5)
                {
                    TValidated = false;
                    message.Append("Music rating b/w 0-5:");
                }
                if (TValidated ==false)
                {
                    throw new MovieException(message.ToString());
                }

            }
            catch (MovieException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return TValidated;
            
            }

        public static bool AddMovieDetailsBL(Movie T)
        {
            bool TAdded = false;

            try
            {
                if (ValidateMovie(T))
                {
                    TAdded = NewMovieOperations.AddMovieDetails(T);
                }
                else
                {
                    throw new MovieException("Please provide valid data for employee");
                }
            }
            catch (MovieException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return TAdded;
        }

        public static List<Movie> RetrieveEmployeeBL()
        {
            List<Movie> MTList = NewMovieOperations.RetrieveEmployeesDal();

            return MTList;
        }


        public static bool SerializeMovie()
            {
                bool TSerialized = false;

                try
                {
                    TSerialized = MovieValidation.SerializeMovie();
                }
                catch (MovieException ex)
                {
                    throw ex;
                }
                catch (SystemException ex)
                {
                    throw ex;
                }

                return TSerialized;
            }

            public static List<Movie> DeserializeMovie()
            {
                List<Movie> TDesList = null;

                try
                {
                    TDesList = MovieValidation.DeserializeMovie();
                }
                catch (MovieException ex)
                {
                    throw ex;
                }
                catch (SystemException ex)
                {
                    throw ex;
                }

                return TDesList;
            }
        }
    }
            

