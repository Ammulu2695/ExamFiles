﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Osss
{
    public class OS
    {
        public int CustomerId { set; get; }
        public List<string> Cart { set; get; }
    }
}
