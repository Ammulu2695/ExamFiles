﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TRS.Entity;
using TRS.Exception;
using TRS.DAL;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;


namespace TRS.BLL
{
    public class TicketValidations
    {
        public static bool ValidateTicket(Ticket T)
        {
            bool TValidated = true;
            StringBuilder message = new StringBuilder();

            try
            {
                //Checking - employee id should be 6 digit
                if (T.PNRNO < 799999 || T.PNRNO > 999999)
                {
                    TValidated = false;
                    message.Append("Employee ID should be exactly 6 digits long\n");
                }

                //Checking - employee name
                //if (T.TicketType == String.Empty)
                //{
                //    TValidated = false;
                //    T.TicketType = "SLEEPER";

                //}
                
                if (T.TicketType == String.Empty)
                {
                    
                    T.TicketType = "SLEEPER";

                }
                if (T.TicketType!= "SLEEPER" &&
                      T.TicketType != "3AC" &&
                      T.TicketType != "2AC" &&
                      T.TicketType  != "1AC")
                {
                    TValidated = false;
                    message.Append("TicketType should be either SLEEPER or 3AC or 2AC or 1AC\n");
                }
                if (T.DOJ < DateTime.Now)
                {
                    TValidated = false;
                    message.Append(" date must be before present day ");
                }
                //if (T.DOJ > DateTime.Today)
                //{
                //    TValidated = false;
                //    message.Append(" date must be before present day ");
                //}
                if (T.BookingDate == DateTime.Now)
                {
                    TValidated = false;
                    message.Append(" date must be  present day ");
                }
                if (TValidated == false)
                {
                    throw new TicketException(message.ToString());
                }
            }




            catch (TicketException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return TValidated;
        }

        public static bool AddTicketDetailsBL(Ticket T)
        {
            bool TAdded = false;

            try
            {
                if (ValidateTicket(T))
                {
                    TAdded = TicketOperation.AddTicketDetails(T);
                }
                else
                {
                    throw new TicketException("Please provide valid data for employee");
                }
            }
            catch (TicketException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return TAdded;
        }
        public static List<Ticket> DisplayTickets()
        {
            List<Ticket> TList = TicketOperation.DisplayTickets();

            return TList;
        }
        public static Ticket SearchTicket(int Id)
        {
            Ticket T = null;

            try
            {
                T = TicketOperation.SearchTicket(Id);
            }
            catch (TicketException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return T;
        }
      
        public static bool SerializeTicket()
        {
            bool TSerialized = false;

            try
            {
                TSerialized = TicketValidations.SerializeTicket();
                if (TSerialized)
                {
                    Console.WriteLine("book details are serialized");
                }
                else
                {
                    throw new TicketException("book details are not serialized");
                }
            }
            catch (TicketException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return TSerialized;
        }

        public static List<Ticket> DeserializeTicket()
        {
            List<Ticket> TDesList = null;

            try
            {
                TDesList = TicketValidations.DeserializeTicket();
            }
            catch (TicketException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return TDesList;
        }


    }
}
    

