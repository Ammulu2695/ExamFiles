﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TRS.Entity;
using TRS.Exception;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;


namespace TRS.DAL
{
    public class TicketOperation
    {
        static List<Ticket> TList = new List<Ticket>();

        //To insert the employee record in employee list
        public static bool AddTicketDetails(Ticket T)
        {
            bool TAdded = false;

            try
            {
                //Adding employee object into employee list
                TList.Add(T);
                TAdded = true;
            }
            catch (TicketException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return TAdded;
        }
        public static Ticket SearchTicket(int Id)
        {
            Ticket T = null;

            try
            {
                //Searching Employee
                T = TList.Find(e => e.PNRNO == Id);
               
                
                //return T;
            }
            catch (TicketException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return T;
        }
        public static List<Ticket> DisplayTickets()
        {
            return TList;
        }

        public static bool SerializeTicket()
        { 
            bool TSerialized = false;

            try
            {
                FileStream fs = new FileStream("Employee.txt", FileMode.Create, FileAccess.Write);
                BinaryFormatter bin = new BinaryFormatter();
                bin.Serialize(fs, TList);
                fs.Close();
                TSerialized = true;
            }
            catch (TicketException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return TSerialized;
        }

        //To deserialize employee List
        public static List<Ticket> DeserializeTicket()
        {
            List<Ticket> TDesList = null;

            try
            {
                FileStream fs = new FileStream("Employee.txt", FileMode.Open, FileAccess.Read);
                BinaryFormatter bin = new BinaryFormatter();
                TDesList = (List<Ticket>)bin.Deserialize(fs);
                fs.Close();
            }
            catch (TicketException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return TDesList;
        }
       

    }
}
