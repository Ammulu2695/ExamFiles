﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TRS.Exception
{
    public class TicketException : ApplicationException
    {
        
    
        //Default Constructor
        public TicketException() : base()
        { }

        //Parameterized Constructor to initialize Message property
        public TicketException(string message) : base(message)
        { }
    }
}
