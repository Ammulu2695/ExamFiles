﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TRS.Entity;
using TRS.Exception;
using TRS.BLL;

namespace TRS.PL
{
    class Program
    {
        public static void AddTicket()
        {
            try
            {
                Ticket T = new Ticket();
                Console.Write("Enter PNRNO : ");
                T.PNRNO = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter Source : ");
                T.Source = Console.ReadLine();
                Console.Write("enter the Destination : ");
                T.Destination = Console.ReadLine();
                Console.Write("enter the Date of journy: ");
                T.DOJ = Convert.ToDateTime(Console.ReadLine());
                Console.Write("enter the BookingDate : ");
                T.BookingDate = Convert.ToDateTime(Console.ReadLine());

                Console.Write("select Ticket type ");
                T.TicketType = Console.ReadLine();
                Console.Write("select the No Of Tickets : ");
                T.NoOfTickets = Convert.ToInt32(Console.ReadLine());


                bool TAdded = TicketValidations.AddTicketDetailsBL(T);

                if (TAdded)
                {
                    //string ch;
                    //ch = Console.ReadLine();
                    //switch (ch)
                    //{
                    //    case "1AC":
                    //        T.Price = T.NoOfTickets * 300;
                    //        break;
                            
                            

                    //}

                    
                    Console.WriteLine("Ticket added successfully");
                }
                else
                {
                    throw new TicketException("Ticket not added");
                }
            }
            catch (TicketException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
           
        }
        public static void SearchTicket()
        {
            try
            {
                int Id;
                Console.Write("Enter Ticket no to be Searched : ");
                Id = Convert.ToInt32(Console.ReadLine());

                Ticket T = TicketValidations.SearchTicket(Id);

                if (T != null)
                {
                    Console.WriteLine($"Employee ID : {T.PNRNO}");
                    Console.WriteLine($"Source : {T.Source}");
                    Console.WriteLine($"Destination : {T.Destination}");
                    Console.WriteLine($"Date of Journey  : {T.DOJ}");
                    Console.WriteLine($"BookingDate : {T.BookingDate}");
                    Console.WriteLine($"TicketType : {T.TicketType}");
                    Console.WriteLine($"NoOfTickets : {T.NoOfTickets}");
                   
                }
                else
                {

                    throw new TicketException("ticket not found");
                }
            }
            catch (TicketException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public static void DisplayTickets()
        {
            try
            {
                List<Ticket> TList = TicketValidations.DisplayTickets();
                
                if (TList != null || TList.Count > 0)
                {
                    Console.WriteLine("------------------------------------------------------------------------------------");
                    Console.WriteLine("PNRNO Source  Destination  Date of journy  BookingDate TicketType  NoOfTickets");
                    Console.WriteLine("------------------------------------------------------------------------------------");
                    foreach (var T in TList)
                    {

                        Console.WriteLine($"{T.PNRNO}\t\t{T.Source}\t{T.Destination}\t{T.DOJ}\t{T.BookingDate}\t{T.TicketType}\t{T.NoOfTickets}");
                    }
                    Console.WriteLine("------------------------------------------------------------------------------------");
                }
                else
                {
                    throw new TicketException("Ticket data not available");
                }
            }
            catch (TicketException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void SerializeTicket()
        {
            try
            {
                bool empSerialized = TicketValidations.SerializeTicket();

                if (empSerialized)
                {
                    Console.WriteLine("ticket data serialized");
                }
                else
                {
                    throw new TicketException("ticket data not serialized");
                }
            }
            catch (TicketException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void DeserializeTicket()
        {
            try
            {
                List<Ticket> TList = TicketValidations.DeserializeTicket();

                if (TList != null || TList.Count > 0)
                {
                    Console.WriteLine("------------------------------------------------------------------------------------");
                    Console.WriteLine("PNRNO Source  Destination  Date of journy  BookingDate TicketType  NoOfTickets");
                    Console.WriteLine("------------------------------------------------------------------------------------");
                    foreach (var T in TList)
                    {
                        Console.WriteLine($"{T.PNRNO}\t\t{T.Source}\t{T.Destination}\t{T.DOJ}\t{T.BookingDate}\t{T.TicketType}\t{T.NoOfTickets}");
                    }
                    Console.WriteLine("-------------Data Deserialized.....");
                }
                else
                {
                    throw new TicketException("Ticket data not available after deserialization");
                }
            }
            catch (TicketException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public static void PrintMenu()
        {
            Console.WriteLine("***********************");
            Console.WriteLine("1.Add TIcket ");
            Console.WriteLine("2.Search TIcket ");
            Console.WriteLine("3. Serialize Ticket");
            Console.WriteLine("4. Deserialize Ticket");
            Console.WriteLine("5.display");
            Console.WriteLine("6. Exit");
            Console.WriteLine("***********************");
        }
            static void Main(string[] args)
          {
            int choice;

            do
            {
                PrintMenu();
                Console.Write("Enter your choice : ");
                choice = Convert.ToInt32(Console.ReadLine());

               switch (choice)
                {
                    case 1:
                        AddTicket();
                        break;
                    case 2:
                        SearchTicket();
                        break;
                    case 3:
                        SerializeTicket();
                        break;
                    case 4:
                        DeserializeTicket();
                        break;
                    case 5:
                        DisplayTickets();
                        break;
                    //case 6:
                    //    SerializeEmployee();
                    //    break;
                    //case 7:
                    //    DeserializeEmployee();
                    //    break;
                    case 6:
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Enter valida choice");
                        break;
                }
            } while (choice != 6);

            Console.ReadKey();
        }
    }
 }
   

