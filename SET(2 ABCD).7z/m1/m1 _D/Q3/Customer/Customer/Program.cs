﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace customer
{
    class Program
    {
        List<customer> lc = new List<customer>();

        //Adding Customer Details 
        public void AddCustomer()

        {
            try
            {
                customer c = new customer(101,201,"Gayathri",3456,"Airoli","SE@dr",56,98);
                customer c1 = new customer(102, 202, "vidhu", 3466, "thane", "gtg@dfr", 57, 98);
                customer c2 = new customer(103, 203, "siri", 1456, "CST", "ser@fr", 58, 98);
                customer c3 = new customer(104, 204, "sindhu",5456, "Vashi", "sf@yu", 59, 98);
                customer c4 = new customer(105, 205, "sam", 3496, "Mumbai", "gt@dewr", 60, 98);





                lc.Add(c);

                Choice();
            }catch(CustomerNotFoundException cne)
            {
                Console.WriteLine(cne.Message);
            }
        }


        //Displaying the customer Details
        public void displaylist()

        {
            try
            {

                if (lc.Count == 0 || lc == null)

                {

                    Console.WriteLine("No records");

                }

                else

                {
                    for (int i = 0; i < 5; i++)
                    {


                        foreach (var cus in lc)

                        {
                            Console.WriteLine("Bill No:" + cus.BillNo);

                            Console.WriteLine("Customer ID:" + cus.CustomerID);

                            Console.WriteLine("Customer Name:" + cus.CustomerName);

                            Console.WriteLine("Customer phone number:" + cus.MobileNo);

                            Console.WriteLine("Customer Address:" + cus.Address);

                            Console.WriteLine("Customer Mail ID:" + cus.Email);

                            Console.WriteLine("Units Consumed:" + cus.UnitsConsumed);

                            Console.WriteLine("Rate Per Unit:" + cus.Rate);

                            //cus.Amount = cus.UnitsConsumed * cus.Rate;
                            //Console.WriteLine("Amount:" + cus.Amount);

                            //cus.SurCharge = 5 * cus.Amount / 100;
                            //Console.WriteLine("SurCharge: " + cus.SurCharge);

                            //cus.GrossAmount = cus.Amount + cus.SurCharge;
                            //Console.WriteLine(" GrossAmount:" + cus.GrossAmount);
                            Console.WriteLine("*************************************************");
                        }

                    }

                }
            } catch (CustomerNotFoundException e)
            {
                Console.WriteLine(e.Message);
            }
            Choice();

        }



        public void Choice()

        {

            for (int i = 0; i < 5; i++)
            {

                Console.WriteLine($"\n***********Customer{i} Details***********");

                Console.WriteLine("1. Add Customer");

                Console.WriteLine("2. Get all Customer Details");

                Console.WriteLine("Enter your choice");

                int ch = Convert.ToInt32(Console.ReadLine());

                switch (ch)

                {

                    case 1:

                        AddCustomer();

                        break;

                    case 2:

                        displaylist();

                        break;


                }



               
            }


            }
            static void Main(string[] args)
            {
                new Program().Choice();

            Console.ReadKey();
            }
        }
    }


