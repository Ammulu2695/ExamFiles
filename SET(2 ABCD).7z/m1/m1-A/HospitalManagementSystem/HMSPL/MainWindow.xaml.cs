﻿using HMSBLL;
using HMSEntity;
using HMSException;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace HMSPL
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnInsert_Click(object sender, RoutedEventArgs e)
        {
            Patient newPatient = new Patient();
            newPatient.PatientID = int.Parse(txtPatientId.Text);
            newPatient.PatientName = txtPatientName.Text;
            newPatient.Phone = txtPhoneNumber.Text;
            AddPatient(newPatient);
        }
        private static void AddPatient(Patient newPatient)
        {
            try
            {
                bool patientAdded = PatientBLL.AddPatientBL(newPatient);
                if (patientAdded)
                    MessageBox.Show("Patient Added");
                else
                    MessageBox.Show("Patient not Added");
            }
            catch (PatientException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private static Patient SearchPatientByID(int searchPatientID)
        {
            Patient SearchedPatient = new Patient();
            try
            {
                SearchedPatient = PatientBLL.SearchPatientBL(searchPatientID);
            }
            catch (PatientException ex)
            {
                MessageBox.Show(ex.Message);
            }
            return SearchedPatient;
        }
        private static void UpdatedPatient(Patient patient)
        {
            try
            {
                bool UpdatedPatient = PatientBLL.UpdatePatientBL(patient);
                if (UpdatedPatient)
                    MessageBox.Show("Patient Updated");
                else
                    MessageBox.Show("Patient not Updated");
            }
            catch (PatientException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            int PatientID = int.Parse(txtPatientId.Text);
            Patient SearchedPatient= SearchPatientByID(PatientID);
            txtPatientName.Text = SearchedPatient.PatientName;
            txtPhoneNumber.Text = SearchedPatient.Phone;

        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            Patient newPatient = new Patient();
            newPatient.PatientID = int.Parse(txtPatientId.Text);
            newPatient.PatientName = txtPatientName.Text;
            newPatient.Phone = txtPhoneNumber.Text;
            UpdatedPatient(newPatient);


        }
    }
}
