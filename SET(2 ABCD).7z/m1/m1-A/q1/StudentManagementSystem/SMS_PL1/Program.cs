﻿using SMS_BAL;
using SMS_Entities;
using SMS_Exceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/*Emp Id:172322
 * Author Name: Susmitha
 * Creation Date:12/02/2019
*/
namespace SMS_PL1
{
    class Program
    {
        public static void AddStudent()
        {
            try
            {
                Student s = new Student();
                Console.WriteLine("Enter the student RollNo");
                s.StudentId= Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter the student Name");
                s.StudentName = Console.ReadLine();
                Console.WriteLine("Enter the Course name");
                s.CourseName= Console.ReadLine();
                Console.WriteLine("Enter the Grade");
                s.Grade= Convert.ToChar(Console.ReadLine());
                
                bool studentAdded = StudentBAL.AddStudentBAL(s);
                if (studentAdded == true)
                {
                    Console.WriteLine("Student added successfully");
                }
                else
                {
                    throw new StudentNotFoundException("Student not added successfully");

                }
                StudentBAL.SerializeData();
            }
            catch (StudentNotFoundException e)
            {
                Console.WriteLine(e.Message);
            }
        }
        public static void DisplayParticularStudent()
        {
            int rollno;
            Student displaystudent;
            try
            {
                Console.WriteLine("Enter student rollno to be displayed");
                rollno = Convert.ToInt32(Console.ReadLine());

                displaystudent = StudentBAL.DisplayParticularStudentBAL(rollno);
                if (displaystudent != null)
                {
                    Console.WriteLine("Student RollNo:" + displaystudent.StudentId);
                    Console.WriteLine("Student Name:" + displaystudent.StudentName);
                    Console.WriteLine("Student Course Name:" + displaystudent.CourseName);
                    Console.WriteLine("Student Grade:" + displaystudent.Grade);
                }
                else
                {
                    throw new StudentNotFoundException("Student not found");
                }
            }
            catch (Exception e2)
            {
                Console.WriteLine(e2.Message);
            }
        }
        static void Main(string[] args)
        {
            PrintMenu();//calling function

        }

        public static void PrintMenu()

        {

            string choice1;//dsiplaying menu

            do

            {

                Console.WriteLine("\n***********Student Management System ***********");

                Console.WriteLine("1. Add the data");

                Console.WriteLine("2. Display performance details of particular student");

                
                Console.WriteLine("Enter your choice");

                int choice = Int32.Parse(Console.ReadLine());

                switch (choice)

                {

                    case 1:

                        AddStudent();

                        break;
                    case 2:
                        DisplayParticularStudent();
                        break;

                    default:

                        Console.WriteLine("Invalid choice");

                        break;

                }

                Console.WriteLine("Do you want to contiue(y/n)?");

                choice1 = Console.ReadLine();

            } while ((choice1!="N"));

            Console.Read();

        }


    }
}
