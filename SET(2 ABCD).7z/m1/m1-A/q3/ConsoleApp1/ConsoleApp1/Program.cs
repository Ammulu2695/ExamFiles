﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*Emp Id:172322
 * Author Name: Susmitha
 * Creation Date:12/02/2019
*/
// Accepting a name of file from user and displaying the details of it


namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                //Giving file path to check if it exists 
                Console.WriteLine("Enter the Path Name");
                string address = Console.ReadLine();
                //get the no of  files from the given directory
                string[] filePaths = Directory.GetFiles($@"{address}");
                Console.WriteLine("No Of Files In the given Path");
                //display the no of files 
                Console.WriteLine($"{filePaths.Length }");
                //get the  no of folders from the given directory
                int directoryCount = System.IO.Directory.GetDirectories($@"{address}").Length;
                Console.WriteLine("No of Folders in the given path");
                //Display the no of folders 
                Console.WriteLine(directoryCount);
            }
            //file io exceptions
            catch (IOException ex)
            {
                Console.WriteLine(ex.Message);
            }

            Console.ReadKey();
        }

    }
}
