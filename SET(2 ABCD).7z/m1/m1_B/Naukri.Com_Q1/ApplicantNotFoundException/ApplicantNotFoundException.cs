﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Naukri_Exceptions
{

    [Serializable]
    public class ApplicantNotFoundException : Exception
    {
        public ApplicantNotFoundException() { }
        public ApplicantNotFoundException(string message) : base(message) { }
        public ApplicantNotFoundException(string message, Exception inner) : base(message, inner) { }
        protected ApplicantNotFoundException(
          System.Runtime.Serialization.SerializationInfo info,
          System.Runtime.Serialization.StreamingContext context) : base(info, context) { }
    }
}
