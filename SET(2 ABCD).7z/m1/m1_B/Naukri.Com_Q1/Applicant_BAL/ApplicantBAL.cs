﻿
using Naukri_DAL;
using Naukri_Entities;
using Naukri_Exceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Applicant_BAL
{
    public class ApplicantBAL
    {
        public static List<Applicant> stud = new List<Applicant>();
        public static object studs;

        private static bool ValidateApplicant(Applicant applicant)
        {
            StringBuilder sb = new StringBuilder();
            bool validStudent = true;
            if ((applicant.City != "Mumbai") && (applicant.City != "Pune") && (applicant.City != "Chennai") && (applicant.City != "Banglore"))
            {
                validStudent = false;
                sb.Append(Environment.NewLine + "city should be Mumbai, Pune, Chennai, Banglore and in same format");
            }
            if ((applicant.Qualification != "BE") && (applicant.Qualification != "ME") && (applicant.Qualification != "MCA"))
            {
                validStudent = false;
                sb.Append(Environment.NewLine + "Qualification has to be BE, ME , MCA and should be in same format as capitals");
            }
            if (applicant.MobileNo.Length != 10)
            {
                validStudent = false;
                sb.Append(Environment.NewLine + "Required 10 Digit Contact Number");
            }
            if (validStudent == false)
                throw new ApplicantNotFoundException(sb.ToString());
            return validStudent;
        }

        public static bool AddApplicantBAL(Applicant newapplicant)
        {
            bool applicantAdded = false;
            try
            {
                if (ValidateApplicant(newapplicant))
                {
                    Applicant_DAL applicantDAL = new Applicant_DAL();
                    applicantAdded = applicantDAL.AddApplicantDAL(newapplicant);
                }
            }
            catch (ApplicantNotFoundException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return applicantAdded;
        }

        public static void SerializeData()
        {
            Applicant_DAL.SerializeData();
        }

        public static void DeserializeData()
        {
            Applicant_DAL.DeserializeData();
        }

        public static Applicant SearchApplicantBAL(string searchApplicantQual)
        {
            Applicant searchApplicant = null;
            try
            {
                Applicant_DAL studentDAL = new Applicant_DAL();
                searchApplicant = studentDAL.SearchApplicantDAL(searchApplicantQual);
            }
            catch (ApplicantNotFoundException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchApplicant;

        }
    }
}
