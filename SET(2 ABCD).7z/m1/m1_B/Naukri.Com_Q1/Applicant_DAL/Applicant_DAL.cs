﻿
using Naukri_Entities;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace Naukri_DAL
{
    public class Applicant_DAL
    {
        public static List<Applicant> appl = new List<Applicant>();

        public bool AddApplicantDAL(Applicant applicant)
        {
            bool applicantAdded = false;
            try
            {
                appl.Add(applicant);
                applicantAdded = true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return applicantAdded;
        }

        public Applicant SearchApplicantDAL(string qual)
        {

            try
            {
                Applicant searchApplicant= null;
                foreach (var applicant in appl)
                {
                    if (applicant.Qualification == qual)
                    {
                        searchApplicant = applicant;
                    }

                }
                return searchApplicant;
            }
            catch (Exception e)
            {
                throw e;
            }

        }

        public static void SerializeData()
        {
            FileStream stream;
            try
            {
                stream = new FileStream(@"Applicant.txt", FileMode.Create, FileAccess.Write);
                BinaryFormatter formatter = new BinaryFormatter();
                formatter.Serialize(stream, appl);
                stream.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static List<Applicant> DeserializeData()
        {
            FileStream stream = new FileStream(@"Student.txt", FileMode.Open, FileAccess.Read);
            BinaryFormatter formatter = new BinaryFormatter();
            appl = formatter.Deserialize(stream) as List<Applicant>;
            return appl;
        }

    }
}
