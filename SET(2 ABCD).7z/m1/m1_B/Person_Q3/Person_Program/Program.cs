﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Person_Program
{
    class Program
    {
        static void Main(string[] args)
        {
            Person person = new Person("Sravika", 21, 10000);
            GetPropertyValues(person);
            Console.ReadLine();
        }

        private static void GetPropertyValues(Object obj)
        {
            Type t = obj.GetType();
            Console.WriteLine("Type is: {0}", t.Name);
            ///
            /// here we are using propertyinfo
            ///
            PropertyInfo[] props = t.GetProperties();
            foreach (var prop in props)
            {
                if (prop.GetIndexParameters().Length == 0)
                {
                    Console.WriteLine(" {0} ({1}): {2}", prop.Name,
                    prop.PropertyType.Name,
                    prop.GetValue(obj));
                }
                else
                {
                    Console.WriteLine(" {0} ({1}): <Indexed>", prop.Name,
                    prop.PropertyType.Name);
                }
            }
        }
    }
}
