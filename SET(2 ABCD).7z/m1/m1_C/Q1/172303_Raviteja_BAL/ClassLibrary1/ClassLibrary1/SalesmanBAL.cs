﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SalesMan_Entity;
using Exceptions;
using Sales_DAL;
using System.Text.RegularExpressions;

namespace Sales_BAL
{
   
    public class SalesmanBAL
    {
       
            private static bool ValidateSalesman(Salesman Salesman)
            {
            StringBuilder sb = new StringBuilder();
            bool validSalesman = true;
            
            if (Salesman.Name == string.Empty)
            {
                validSalesman = false;
                sb.Append(Environment.NewLine + "Salesman Name Required");

            }
            if (Salesman.Region == string.Empty)
            {
                validSalesman = false;
                sb.Append(Environment.NewLine + "Region Name Required");

            }
           
            if (Salesman.Region.Equals("North") || Salesman.Region.Equals("East") || Salesman.Region.Equals("West")|| Salesman.Region.Equals("South"))
            {
                validSalesman = false;
                sb.Append(Environment.NewLine + " The Region should be from North,East,West,South");

            }

            if (validSalesman == false)
                throw new SalesmanNotFoundException(sb.ToString());
            return validSalesman;
        }
        //for adding purpose
        public static bool AddSalesmanBL(Salesman salesman)
        {
            bool SalesmanAdded = false;
            try
            {
                
                if (ValidateSalesman(salesman))
                {
                    Sales_DAL. SalesmanDAL SalesmanDAL = new Sales_DAL.SalesmanDAL();
                    SalesmanAdded = SalesmanDAL.AddSalesmanDAL(salesman);
                }
            }
            catch (SalesmanNotFoundException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return SalesmanAdded;
        }
        //for searching
        public static Salesman SearchSalesmanBAL(string searchName)
        {
            Salesman searchsalesman = null;
            try
            {
                SalesmanDAL guestDAL = new SalesmanDAL();
                searchsalesman = guestDAL.SearchSalesmanDAL(searchName);
            }
            catch (SalesmanNotFoundException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchsalesman;

        }

        //for serialization
        public static bool SerializeDataBL(Salesman salesman)

        {

            bool salesmanSerialized = false;

            try

            {

                if (ValidateSalesman(salesman))

                {

                    Sales_DAL.SalesmanDAL salesmanDAL = new Sales_DAL.SalesmanDAL();

                    salesmanSerialized = salesmanDAL.SerializeDataDAL(salesman);

                }

            }

            catch (SalesmanNotFoundException e)

            {

                throw;

            }

            catch (Exception ex)

            {

                throw ex;

            }

            return salesmanSerialized;

        }
      

        public static List<Salesman> DeserializeDataBL()

        {

            List<Salesman> salesmanList = null;

            try

            {

                Sales_DAL.SalesmanDAL salesmanDAL = new Sales_DAL.SalesmanDAL();

                salesmanList = salesmanDAL.DeserializeDataDAL();

            }

            catch (SalesmanNotFoundException ex)

            {

                throw ex;

            }

            catch (Exception ex)

            {

                throw ex;

            }

            return salesmanList;

        }

    }

}
    

