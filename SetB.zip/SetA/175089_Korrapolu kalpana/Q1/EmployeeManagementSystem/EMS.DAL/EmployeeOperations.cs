﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EMS.Entity;
using EMS.Exception;
using System.IO;
using System.Collections;
using System.Runtime.Serialization.Formatters.Binary;

namespace EMS.DAL
{
    /// <summary>
    /// Employee Id:175089
    /// Employee Name:Korrapolu Kalpana
    /// Date of Creation: Database operations on Employee Class
    /// </summary>
    public class EmployeeOperations
    {
        static List<Employee> empList = new List<Employee>();
        //To register the employee record in employee list
        public static bool AddEmployee(Employee emp)
        {
            bool empAdded = false;

            try
            {
                //Adding employee object into employee list
                empList.Add(emp);
                empAdded = true;
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return empAdded;
        }
        //To retrieve all employees
        public static List<Employee> RetrieveEmployees()
        {
            return empList;
        }
        //To Serialize employee list
        public static bool SerializeEmployee()
        {
            

            bool empSerialized = false;

            try
            {
                FileStream fs = new FileStream("Employee.txt", FileMode.Create, FileAccess.Write);
                ArrayList arrList = new ArrayList();
                BinaryFormatter bin = new BinaryFormatter();
                bin.Serialize(fs, arrList);
                fs.Close();
                empSerialized = true;
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return empSerialized;
        }
        //To deserialize employee List
        public static List<Employee> DeserializeEmployee()
        {
            
            List<Employee> empDesList = null;

            try
            {
                FileStream fs = new FileStream("Employee.txt", FileMode.Open, FileAccess.Read);
                BinaryFormatter bin = new BinaryFormatter();
                empDesList = (List<Employee>)bin.Deserialize(fs);
                fs.Close();
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return empDesList;
        }
    }
}
