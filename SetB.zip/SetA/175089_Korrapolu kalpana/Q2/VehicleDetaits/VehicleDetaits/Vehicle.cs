﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VehicleDetaits
{
    /// <summary>
    /// Employee Id:175089
    /// Employee Name:Korrapolu Kalpana
    /// Date of Creation:12-March-2019
    /// Description:class have properties and parameterized constructor for Vehicle class
    class Vehicle
    {
        public int Speed { get; set; }
        public string Color { get; set; }
        public Vehicle(int speed,string color)
        {
            Speed = speed;
            Color = color;
        }


    }
    class VehicleComparer:IComparer<Vehicle>
    {
        public int Compare(Vehicle vehicle1,Vehicle vehicle2)
        {
            if (vehicle1.Speed > vehicle2.Speed)
            {
                return 1;
            }
            else if(vehicle1.Speed<vehicle2.Speed)
            {
                return -1;
            }
            return 0;
                
        }

        
    }
}
