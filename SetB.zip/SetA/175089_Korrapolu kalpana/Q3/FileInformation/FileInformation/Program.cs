﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace FileInformation
{
    /// <summary>
    /// Employee id:175089
    /// Employee Name:korrapolu kalpana
    /// Date of Creation:12-March-2019
    /// Description:if file exists file then display File Information or error occurs
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            string filename;
            Console.WriteLine("Enter the filename:");
            filename = Console.ReadLine();
            FileInfo file = new FileInfo(filename);
            if(file.Exists)
            {
                Console.WriteLine($"Parent directory of the file:{file.Directory.Name}");
                Console.WriteLine($"Extension of the file:{file.Extension}");
                Console.WriteLine($"Full file path:{file.FullName}");
                Console.WriteLine($"Length of the file:{file.Length}");
                Console.WriteLine($"Creation time of the file:{file.CreationTime}");
            }
            else
            {
                Console.WriteLine("file does not exists");
            }
            Console.ReadKey();
        }
    }
}
