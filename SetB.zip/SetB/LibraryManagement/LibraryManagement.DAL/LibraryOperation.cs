﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LibraryManagement;
using LibraryManagementExcetion;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;


namespace LibraryManagement.DAL
{
    public class LibraryOperation
    {
        
            static List<Book> bookList = new List<Book>();

            //To insert the employee record in employee list
            public static bool AddBookDetails(Book B)
            {
                bool BAdded = false;

                try
                {
                    //Adding employee object into employee list
                    bookList.Add(B);
                    BAdded = true;
                }
                catch (LibraryException ex)
                {
                    throw ex;
                }
                catch (SystemException ex)
                {
                    throw ex;
                }

                return BAdded;
            }
        public static bool SerializeBook()
        {
            bool BSerialized = false;

            try
            {
                FileStream fs = new FileStream("Book.txt", FileMode.Create, FileAccess.Write);
                BinaryFormatter bin = new BinaryFormatter();
                bin.Serialize(fs, bookList);
                fs.Close();
                BSerialized = true;
            }
            catch (LibraryException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return BSerialized;
        }
        public static List<Book> DeserializeBook()
        {
            List<Book> BDesList = null;

            try
            {
                FileStream fs = new FileStream("book.txt", FileMode.Open, FileAccess.Read);
                BinaryFormatter bin = new BinaryFormatter();
                BDesList = (List<Book>)bin.Deserialize(fs);
                fs.Close();
            }
            catch (LibraryException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return BDesList;
        }
    }
}
