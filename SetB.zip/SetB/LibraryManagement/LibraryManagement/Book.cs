﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryManagement
{
    public class Book
    {
        public int BookId { set; get; }

        public string BookName { set; get; }

        public string Language { set; get; }

        public double  Price {set;get;}

        public string ISBN_NO { set; get; }

        public int NumberOfPages { set; get; }

        public string Iot { set; get; }

        public string summary { set; get; }


    }
}
