﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q1_ABC.Exception
{
    public class CustomerException:ApplicationException
    {

        /// <summary>
        /// Employee ID : 174790
        /// Employee Name :PERAKAM ANANTHANADH
        /// Date of Creation : 12-Mar-2019
        /// Description : User defined exception class to handle exception of Customer
        /// </summary>

        //Default Constructor
        public CustomerException() : base()
        { }

        //Parameterized Constructor to initialize Message property
        public  CustomerException(string message) : base(message)
        { }
    }
}
