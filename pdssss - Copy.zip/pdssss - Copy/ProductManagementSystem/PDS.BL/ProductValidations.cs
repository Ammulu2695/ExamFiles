﻿using PDS.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PDS.Exception;
using PDS.Dal;
using System.Text.RegularExpressions;

namespace PDS.BL
{
    public class ProductValidations
    {
        //To validate pdtloyee details
        public static bool ProductValidate(Product pdt)
        {
            bool pdtValidated = true;
            StringBuilder message = new StringBuilder();

            try
            {
                //Checking - pdtloyee id should be 6 digit
                //if ((pdt.ProductID).ToString==object.Equals(object ))
                //{
                //    pdtValidated = false;
                //    message.Append("pdtloyee ID should be exactly 6 digits long\n");
                //}
                if (pdt.ProductID==string.Empty)
                {
                    pdtValidated = false;
                    message.Append("Product Id should not be blank");
                }

                //Checking - pdtloyee name
                if (pdt.ProductName == String.Empty)
                {
                    pdtValidated = false;
                    message.Append("pdtloyee Name should be provided\n");
                }
                else if (!Regex.IsMatch(pdt.ProductName, "[A-Z][a-z]{2,}"))
                {
                    pdtValidated = false;
                    message.Append("pdtloyee Name should start with capital alphabet and it should have minimum 3 alphabets\n");
                }

                /* //Checking Phone number
                 if (pdt.PhoneNo == string.pdt)
                 {
                     pdtValidated = false;
                     message.Append("Phone number should be provided\n");
                 }
                 else if (!Regex.IsMatch(pdt.PhoneNo, "[6-9][0-9]{9}"))
                 {
                     pdtValidated = false;
                     message.Append("Phone number should start with 6/7/8/9 and it should have exactly 10 digits\n");
                 }*/

                //Checking price

                if (pdt.price < 500 || pdt.price > 2000)
                {
                    pdtValidated = false;
                    message.Append("Price should be between 500 And 2000\n");
                }

                //Checking Date of manufactured
                if (/*pdt.MFD == (DateTime.Now) &&*/ pdt.MFD > pdt.DOB)
                {
                    pdtValidated = false;
                    message.Append("Date of MANUFACTURED should NOT today's date");
                }


                /* //Checking City
                 if (pdt.City == string.pdtty)

                 {
                     pdtValidated = false;
                     message.Append("City should be provided");
                 }
                 else if (pdt.City.ToLower() != "pune" &&
                         pdt.City.ToLower() != "mumbai" &&
                         pdt.City.ToLower() != "hyderabad" &&
                         pdt.City.ToLower() != "bangalore")
                 {
                     pdtValidated = false;
                     message.Append("City should be either Pune or Mumbai or Hyderabad or Bangalore\n");
                 }*/

               // else
               // {
               //     throw new ProductExceptions("please provide BEFORE todays date");

               //}

                //if (pdt.DOB != DateTime.Now)
                //{
                //    pdtValidated = false;
                //    message.Append("Date of buy should  today's date");
                //}
                //else
                //{
                //    throw new ProductExceptions("please do not  provide todays date");
                //}

                if (pdtValidated == false)
                {
                    throw new ProductExceptions(message.ToString());
                }
            }
            catch (ProductExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return pdtValidated;
        }



        public static bool AddProduct(Product pdt)
        {
            bool pdtAdded = false;

            try
            {
                if (ProductValidate(pdt))
                {
                    pdtAdded = ProductOperations.AddProduct(pdt);
                }
                else
                {
                    throw new ProductExceptions("Please provide valid data for product");
                }
            }
            catch (ProductExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return pdtAdded;
        }

        /*    public static bool Updatepdtloyee(pdtloyee pdt)
            {
                bool pdtUpdated = false;

                try
                {
                    if (Validatepdtloyee(pdt))
                    {
                        pdtUpdated = pdtloyeeOperations.Updatepdtloyee(pdt);
                    }
                    else
                    {
                        throw new pdtloyeeException("Please provide valid data to update pdtloyee");
                    }
                }
                catch (pdtloyeeException ex)
                {
                    throw ex;
                }
                catch (SystemException ex)
                {
                    throw ex;
                }

                return pdtUpdated;
            }

            public static bool Deletepdtloyee(int pdtID)
            {
                bool pdtDeleted = false;

                try
                {
                    pdtDeleted = pdtloyeeOperations.Deletepdtloyee(pdtID);
                }
                catch (pdtloyeeException ex)
                {
                    throw ex;
                }
                catch (SystemException ex)
                {
                    throw ex;
                }

                return pdtDeleted;
            }*/

            public static Product SearchProduct(string pdtID)
            {
                Product pdt = null;

                try
                {
                    pdt = ProductOperations.SearchProduct(pdtID);
                }
                catch (ProductExceptions ex)
                {
                    throw ex;
                }
                catch (SystemException ex)
                {
                    throw ex;
                }

                return pdt;
            }
       
        public static List<Product> RetrieveProduct()
            {
                List<Product> pdtList = ProductOperations.RetrieveProducts();

                return pdtList;
            }

        public static bool SerializeProduct()
        {
            bool pdtSerialized = false;

            try
            {
                pdtSerialized = ProductOperations.SerializeProduct();
            }
            catch (ProductExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return pdtSerialized;
        }

        public static List<Product> Deserializeproduct()
        {
            List<Product> pdtDesList = null;

            try
            {
                pdtDesList = ProductOperations.DeserializeProduct();
            }
            catch (ProductExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return pdtDesList;
        }

        
    }
}


    
    






