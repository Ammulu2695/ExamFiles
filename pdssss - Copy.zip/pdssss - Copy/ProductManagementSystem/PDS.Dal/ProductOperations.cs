﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using PDS.Entity;
using PDS.Exception;
namespace PDS.Dal
{
    public class ProductOperations
    {

            static List<Product> pdtList = new List<Product>();

            //To insert the Product record in Product list
            public static bool AddProduct(Product pdt)
            {
                bool pdtAdded = false;

                try
                {
                    //Adding Product object into Product list
                    pdtList.Add(pdt);
                    pdtAdded = true;
                }
                catch (ProductExceptions ex)
                {
                    throw ex;
                }
                catch (SystemException ex)
                {
                    throw ex;
                }

                return pdtAdded;
            }

            /*To modify the Product data from the list
            public static bool UpdateProduct(Product pdt)
            {
                bool pdtUpdated = false;

                try
                {
                    for (int i = 0; i < pdtList.Count; i++)
                    {
                        //Searching Product to update
                        if (pdtList[i].ProductID == pdt.ProductID)
                        {
                            //Modifying Product details
                            pdtList[i].ProductName = pdt.ProductName;
                            pdtList[i].PhoneNo = pdt.PhoneNo;
                            pdtList[i].DOB = pdt.DOB;
                            pdtList[i].DOJ = pdt.DOJ;
                            pdtList[i].City = pdt.City;

                            pdtUpdated = true;
                        }
                    }
                }
                catch (ProductExceptionss ex)
                {
                    throw ex;
                }
                catch (SystemException ex)
                {
                    throw ex;
                }

                return pdtUpdated;
            }

            //To delete Product from Product list
            public static bool DeleteProduct(int pdtID)
            {
                bool pdtDeleted = false;

                try
                {
                    //Searching Product
                    Product pdt = pdtList.Find(e => e.ProductID == pdtID);

                    if (pdt != null)
                    {
                        //Deleting Product from Product list
                        pdtList.Remove(pdt);
                        pdtDeleted = true;
                    }
                    else
                    {
                        throw new ProductExceptionss("Product with ID " + pdtID + " does not exist for Delete");
                    }
                }
                catch (ProductExceptionss ex)
                {
                    throw ex;
                }
                catch (SystemException ex)
                {
                    throw ex;
                }

                return pdtDeleted;
            }*/

           
            public static Product SearchProduct(string pdtID)
            {
                Product pdt = null;

                try
                {
                    //Searching Product
                    pdt = pdtList.Find(p => p.ProductID == pdtID);
                }
                catch (ProductExceptions ex)
                {
                    throw ex;
                }
                catch (SystemException ex)
                {
                    throw ex;
                }

                return pdt;
            }

            //To retrieve all Products
            public static List<Product> RetrieveProducts()
            {
                return pdtList;
            }

            //To Serialize Product list
            public static bool SerializeProduct()
            {
                bool pdtSerialized = false;

                try
                {
                    FileStream fs = new FileStream("Product.txt", FileMode.Create, FileAccess.Write);
                    BinaryFormatter bin = new BinaryFormatter();
                    bin.Serialize(fs, pdtList);
                    fs.Close();
                    pdtSerialized = true;
                }
                catch (ProductExceptions ex)
                {
                    throw ex;
                }
                catch (SystemException ex)
                {
                    throw ex;
                }

                return pdtSerialized;
            }

            //To deserialize Product List
            public static List<Product> DeserializeProduct()
            {
                List<Product> pdtDesList = null;

                try
                {
                    FileStream fs = new FileStream("Product.txt", FileMode.Open, FileAccess.Read);
                    BinaryFormatter bin = new BinaryFormatter();
                    pdtDesList = (List<Product>)bin.Deserialize(fs);
                    fs.Close();
                }
                catch (ProductExceptions ex)
                {
                    throw ex;
                }
                catch (SystemException ex)
                {
                    throw ex;
                }

                return pdtDesList;
            }
        }
    }



